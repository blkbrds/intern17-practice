//
//  DrawChartViewController.swift
//  Drawing
//
//  Created by Dung Nguyen T.T. [3] VN.Danang on 6/22/22.
//

import UIKit

class DrawChartViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let rectView = DrawChartView(frame: CGRect(x: 30, y: 200, width: 30, height: 100))
//        view.addSubview(rectView)

//        drawLine(start: CGPoint(x: 30, y: 100), end: CGPoint(x: 350, y: 100))
//        drawLine(start: CGPoint(x: 30, y: 150), end: CGPoint(x: 350, y: 150))
//        drawLine(start: CGPoint(x: 30, y: 200), end: CGPoint(x: 350, y: 200))
//        drawLine(start: CGPoint(x: 30, y: 250), end: CGPoint(x: 350, y: 250))
//        lineOfChart()
        
        let screenSize = UIScreen.main.bounds.size
        let view = DungChartView(frame: CGRect(x: 20, y: 50, width: screenSize.width - 40, height: 200))
        
        self.view.addSubview(view)
    }
    
    func frameLineView(frame: CGRect){
        let userView = DrawChartView(frame: frame)
        let lineView = UIView(frame: CGRect(x: 0, y: 50, width: userView.bounds.width, height: userView.bounds.height))
        userView.addSubview(lineView)
        
    }
    
    func lineOfChart() {
        var y = 100
        for _ in 0..<4 {
            drawLine(start: CGPoint(x: 30, y: y), end: CGPoint(x: 350, y: y))
            y += 50
        }
    }
    
    func drawLine(start: CGPoint, end: CGPoint) {
        // PATH
        let path = UIBezierPath()
        path.move(to: start)
        path.addLine(to: end)
        path.close()
        
        //LAYER
        let shapeLayer = CAShapeLayer()
        shapeLayer.strokeColor = UIColor.blue.cgColor
        shapeLayer.lineWidth = 1.0
        shapeLayer.path = path.cgPath
        
        //ADD LAYER
        self.view.layer.addSublayer(shapeLayer)
    }
}
