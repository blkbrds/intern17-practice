//
//  DrawChartView.swift
//  Drawing
//
//  Created by Dung Nguyen T.T. [3] VN.Danang on 6/22/22.
//

import UIKit

class DrawChartView: UIView {
    
    override func draw(_ rect: CGRect) {
         self.createRectangle()
    }
    
    func createRectangle() {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0.0, y: 0.0))
        path.addLine(to: CGPoint(x: 0.0, y: self.frame.size.height))
        path.addLine(to: CGPoint(x: self.frame.size.width, y: self.frame.size.height))
        path.addLine(to: CGPoint(x: self.frame.size.width, y: 0.0))
        UIColor.orange.setFill()
        path.fill()
        path.close()
    }

}
