//
//  DungChartView.swift
//  Drawing
//
//  Created by Dung Nguyen T.T. [3] VN.Danang on 6/22/22.
//

import UIKit

class DungChartView: UIView {
    
    var backgrounChartdColor: UIColor = UIColor.clear {
        didSet {
            setNeedsDisplay()
        }
    }
    
    var values = [30, 45, 70, 80, 10, 35]
    var color: [UIColor] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        drawBackGround()
        
        drawOxy()
        
        drawValues()
    }
    
    func drawBackGround() {
        // 1. tao path
        let path = UIBezierPath(rect: self.bounds)
        
        // 2.fill mau`
        let fillColor = backgrounChartdColor
        fillColor.setFill()
        
        // 3. fill path
        path.fill()
    }
    
    func drawOxy() {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0.0, y: 0.0))
        path.addLine(to: CGPoint(x: 0.0, y: self.bounds.size.height))
        path.addLine(to: CGPoint(x: self.bounds.size.width, y: self.bounds.size.height))
        
        UIColor.gray.setStroke()
        path.lineWidth = 2.0
        path.stroke()
        
        path.close()
        
        
    }
    
    func drawValues() {
        // array toa do
        let n = values.count + 1
        let detal = self.bounds.size.width / CGFloat(n)
        
        let height = self.bounds.size.height
        for i in 0..<values.count {
            let x = CGFloat(detal * CGFloat((i+1)) - detal/4 )
            let w = detal/2
            let h = CGFloat(Int(height)/100*values[i])
            
            drawRectange(CGRect(x: x, y: height - h, width: w, height: h), color: .blue)
           
        }
        // for values --> rect (toa do) --> drawRectange
    }
    
    func drawRectange(_ rect: CGRect, color: UIColor) {
        let path = UIBezierPath(rect: rect )
        color.setFill()
        path.fill()
        path.close()
    }

}
