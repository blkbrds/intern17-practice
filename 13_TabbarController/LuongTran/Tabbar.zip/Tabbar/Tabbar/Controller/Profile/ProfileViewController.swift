//
//  ProfileViewController.swift
//  Tabbar
//
//  Created by luong.tran on 21/09/2022.
//

import UIKit

final class ProfileViewController: UIViewController {

    @IBOutlet private weak var logoutLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        configNavigation()
        let tap = UITapGestureRecognizer(target: self, action: #selector(logOutButtonTouchUpInside))
        logoutLabel.isUserInteractionEnabled = true
        logoutLabel.addGestureRecognizer(tap)
    }
    
    private func configNavigation() {
        title = Define.title
    }
    
    @objc private func logOutButtonTouchUpInside(sender: UITapGestureRecognizer) {
        if let navigations = self.tabBarController?.viewControllers {
            for item in navigations {
                if let navigation = item as? UINavigationController {
                    navigation.popToRootViewController(animated: false)
                }
            }
        }
    }
}

extension ProfileViewController {
    private struct Define {
        static var title: String = "Profile"
    }
}
