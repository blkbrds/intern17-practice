//
//  LoginViewController.swift
//  Tabbar
//
//  Created by luong.tran on 21/09/2022.
//

import UIKit

final class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        configNavigation()
    }
    
    private func configNavigation() {
        title = Define.title
    }
    
    @IBAction func loginButtonTouchUpInside(_ sender: Any) {
        
    }
}

extension LoginViewController {
    private struct Define {
        static var title: String = "Login"
    }
}
