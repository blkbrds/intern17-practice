//
//  AppDelegate.swift
//  Tabbar
//
//  Created by luong.tran on 21/09/2022.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        let userDefaults = UserDefaults.standard
        let loginVC = LoginViewController()
        if let username = userDefaults.string(forKey: "username") {
            let homeVC = HomeViewController()
            homeVC.username = username
            let homeNavigationController = UINavigationController(rootViewController: homeVC)
            homeVC.tabBarItem = UITabBarItem(title: "Home", image: UIImage(systemName: "house.fill"), tag: 0)
            
            let mapVC = MapViewController()
            let mapNavigationController = UINavigationController(rootViewController: mapVC)
            mapVC.tabBarItem = UITabBarItem(title: "Map", image: UIImage(systemName: "map.fill"), tag: 1)
            
            let favoriteVC = FavoriteViewController()
            let favoriteNavigationController = UINavigationController(rootViewController: favoriteVC)
            favoriteVC.tabBarItem = UITabBarItem(title: "Favorites", image: UIImage(systemName: "heart.fill"), tag: 2)
            
            let profileVC = ProfileViewController()
            let profileNavigationController = UINavigationController(rootViewController: profileVC)
            profileVC.tabBarItem = UITabBarItem(title: "Profile", image: UIImage(systemName: "person.fill"), tag: 3)
            
            let viewControllers = [homeNavigationController, mapNavigationController, favoriteNavigationController, profileNavigationController]
            let tabBarController = UITabBarController()
            tabBarController.viewControllers = viewControllers
            tabBarController.tabBar.tintColor = .red
            window?.rootViewController = tabBarController
        } else {
            let navigationController = UINavigationController(rootViewController: loginVC)
            window?.rootViewController = navigationController
        }
        
        
        //Config window
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.makeKeyAndVisible()
        
        return true
    }

}

